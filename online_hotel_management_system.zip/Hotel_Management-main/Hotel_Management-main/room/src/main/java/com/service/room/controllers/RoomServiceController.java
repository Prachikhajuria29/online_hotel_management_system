package com.service.room.controllers;

import java.util.List;

import org.apache.hc.core5.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.service.room.entities.Response;
import com.service.room.entities.RoomService;
import com.service.room.exception.RoomServiceAlreadyExists;
import com.service.room.exception.RoomServiceNotFound;
import com.service.room.services.RoomServices;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/room")
@Tag(name = "Room Service Controller", description = "APIs for managing room services")
public class RoomServiceController {

    private static final Logger logger = LoggerFactory.getLogger(RoomServiceController.class);

    @Autowired
    private RoomServices service;

    @Operation(summary = "Add a new room service")
    @PostMapping("/addRoomService")
    public Response addRoomService(@RequestBody RoomService roomService) {
        logger.info("Received request to add room service: {}", roomService);
        try {
            RoomService result = service.addRoomService(roomService);
            logger.info("Room service added successfully: {}", result);
            return Response.builder()
                    .success(true)
                    .roomService(result)
                    .message("RoomService Started successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (RoomServiceAlreadyExists e) {
            logger.error("Room service already exists: {}", e.getMessage());
            return Response.builder()
                    .success(false)
                    .message(e.getMessage())
                    .roomService(null)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Update a room service")
    @PutMapping("/updateRoomService/{serviceId}")
    public Response updateRoomService(@RequestBody RoomService roomService, @PathVariable int serviceId) {
        logger.info("Received request to update room service with ID {}: {}", serviceId, roomService);
        try {
            RoomService result = service.updateRoomService(roomService, serviceId);
            logger.info("Room service updated successfully: {}", result);
            return Response.builder()
                    .success(true)
                    .roomService(result)
                    .message("RoomService updated successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (RoomServiceNotFound e) {
            logger.error("Room service not found for ID {}: {}", serviceId, e.getMessage());
            return Response.builder()
                    .success(false)
                    .message(e.getMessage())
                    .roomService(roomService)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Delete a room service")
    @DeleteMapping("/deleteRoomService/{serviceId}")
    public Response deleteRoomService(@PathVariable int serviceId) {
        logger.info("Received request to delete room service with ID {}", serviceId);
        try {
            RoomService result = service.deleteRoomService(serviceId);
            logger.info("Room service deleted successfully: {}", result);
            return Response.builder()
                    .success(true)
                    .roomService(result)
                    .message("RoomService deleted successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (RoomServiceNotFound e) {
            logger.error("Room service not found for ID {}: {}", serviceId, e.getMessage());
            return Response.builder()
                    .success(false)
                    .message(e.getMessage())
                    .roomService(null)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Get room service by room number and completion status")
    @GetMapping("/getRoomService/{roomNumber}/{completed}")
    public Response getRoomServiceByRoomNumberAndIsCompleted(@PathVariable String roomNumber,
            @PathVariable boolean completed) {
        logger.info("Received request to get room service for roomNumber {} and completed status {}", roomNumber, completed);
        try {
            RoomService result = service.getRoomServiceByRoomNumberAndIsCompleted(roomNumber, completed);
            logger.info("Room service fetched successfully: {}", result);
            return Response.builder()
                    .success(true)
                    .roomService(result)
                    .message("Room Service fetched successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (RoomServiceNotFound e) {
            logger.error("Room service not found for roomNumber {}: {}", roomNumber, e.getMessage());
            return Response.builder()
                    .success(false)
                    .message(e.getMessage())
                    .roomService(null)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Mark a room service as completed")
    @PostMapping("/setRoomServiceCompleted/{roomNumber}/{completed}")
    public Response setRoomServiceCompleted(@PathVariable String roomNumber, @PathVariable boolean completed) {
        logger.info("Received request to set room service completed for roomNumber {}: {}", roomNumber, completed);
        try {
            boolean result = service.setServiceCompleted(roomNumber, completed);
            logger.info("Room service status updated successfully for roomNumber {}: {}", roomNumber, completed);
            return Response.builder()
                    .success(result)
                    .roomService(null)
                    .message("Room Service completed successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (RoomServiceNotFound e) {
            logger.error("Room service not found for roomNumber {}: {}", roomNumber, e.getMessage());
            return Response.builder()
                    .success(false)
                    .message(e.getMessage())
                    .roomService(null)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Get all active room services")
    @GetMapping("/getActiveRoomServices")
    public List<RoomService> getActiveRoomServices() {
        logger.info("Received request to fetch all active room services");
        return service.getActiveRoomServices();
    }

    @Operation(summary = "Delete an ordered item by ID")
    @DeleteMapping("/deleteOrderedItemById/{id}")
    public void deleteOrderedItemById(@PathVariable int id) {
        logger.info("Received request to delete ordered item by ID {}", id);
        service.deleteOrderedItemById(id);
        logger.info("Ordered item deleted successfully for ID {}", id);
    }
}
