package com.service.room.exception;

public class RoomServiceAlreadyExists extends Exception {
    public RoomServiceAlreadyExists(String message) {
        super(message);
    }
}
