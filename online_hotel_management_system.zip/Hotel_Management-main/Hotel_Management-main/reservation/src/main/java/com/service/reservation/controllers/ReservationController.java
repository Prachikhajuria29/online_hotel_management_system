package com.service.reservation.controllers;

import java.util.List;

import org.apache.hc.core5.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.service.reservation.entities.Reservation;
import com.service.reservation.entities.Response;
import com.service.reservation.entities.Room;
import com.service.reservation.exception.ReservationNotFoundException;
import com.service.reservation.exception.RoomTypeNotAvailable;
import com.service.reservation.services.ReservationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/reservation")
@Tag(name = "Reservation Controller", description = "APIs for managing reservations")
public class ReservationController {

    private static final Logger logger = LoggerFactory.getLogger(ReservationController.class);

    @Autowired
    private ReservationService reservationService;

    @Operation(summary = "Get all available rooms")
    @GetMapping("/getAvailableRooms")
    public List<Room> getAvailableRooms() {
        logger.info("Fetching available rooms");
        return reservationService.getAvailableRooms();
    }

    @Operation(summary = "Add a new reservation")
    @PostMapping("/addReservation")
    public Response addReservation(@RequestBody Reservation reservation) {
        logger.info("Received request to add reservation: {}", reservation);
        try {
            Reservation result = reservationService.addReservation(reservation);
            if (result != null) {
                logger.info("Reservation added successfully: {}", result);
                return Response.builder()
                        .success(true)
                        .reservation(result)
                        .message("Reservation added successfully")
                        .code(HttpStatus.SC_OK)
                        .build();
            } else {
                logger.error("Failed to add reservation: {}", reservation);
                return Response.builder()
                        .success(false)
                        .message("Reservation not added successfully/Room not available")
                        .reservation(null)
                        .code(HttpStatus.SC_BAD_REQUEST)
                        .build();
            }
        } catch (RoomTypeNotAvailable e) {
            logger.error("Room type not available: {}", e.getMessage());
            return Response.builder()
                    .success(false)
                    .message(e.getMessage())
                    .reservation(null)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Update reservation details")
    @PutMapping("/updateReservation/{reservationId}")
    public Response updateReservation(@RequestBody Reservation reservation, @PathVariable int reservationId) {
        logger.info("Received request to update reservation with ID {}: {}", reservationId, reservation);
        try {
            Reservation result = reservationService.updatReservation(reservation, reservationId);
            logger.info("Reservation updated successfully: {}", result);
            return Response.builder()
                    .success(true)
                    .reservation(result)
                    .message("Reservation updated successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (ReservationNotFoundException e) {
            logger.error("Failed to update reservation with ID {}: {}", reservationId, e.getMessage());
            return Response.builder()
                    .success(false)
                    .message("Reservation not updated successfully")
                    .reservation(null)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Delete a reservation by ID")
    @DeleteMapping("/deleteReservation/{reservationId}")
    public Response deleteReservation(@PathVariable int reservationId) {
        logger.info("Received request to delete reservation with ID {}", reservationId);
        try {
            Reservation result = reservationService.deleteReservation(reservationId);
            logger.info("Reservation deleted successfully: {}", result);
            return Response.builder()
                    .success(true)
                    .reservation(result)
                    .message("Reservation deleted successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (ReservationNotFoundException e) {
            logger.error("Failed to delete reservation with ID {}: {}", reservationId, e.getMessage());
            return Response.builder()
                    .success(false)
                    .message("Reservation not deleted successfully")
                    .reservation(null)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Get a reservation by ID")
    @GetMapping("/getReservationById/{reservationId}")
    public Response getReservationById(@PathVariable int reservationId) {
        logger.info("Fetching reservation with ID {}", reservationId);
        Reservation result = reservationService.getReservationById(reservationId);
        if (result != null) {
            logger.info("Reservation fetched successfully: {}", result);
            return Response.builder()
                    .success(true)
                    .reservation(result)
                    .message("Reservation fetched with ID " + reservationId)
                    .code(HttpStatus.SC_OK)
                    .build();
        } else {
            logger.error("Reservation not found with ID {}", reservationId);
            return Response.builder()
                    .success(false)
                    .message("Reservation not found with ID " + reservationId)
                    .reservation(null)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Get all active reservations")
    @GetMapping("/getActiveReservations")
    public List<Reservation> getActiveReservations() {
        logger.info("Fetching active reservations");
        return reservationService.getActiveReservations();
    }

    @Operation(summary = "Delete a guest by ID")
    @DeleteMapping("/deleteGuest/{guestId}")
    public void deleteGuest(@PathVariable int guestId) {
        logger.info("Received request to delete guest with ID {}", guestId);
        reservationService.deleteGuestById(guestId);
        logger.info("Guest with ID {} deleted successfully", guestId);
    }
}
