package com.service.authentication.controller;

import org.apache.hc.core5.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.service.authentication.entities.Response;
import com.service.authentication.entities.User;
import com.service.authentication.exception.UserErrorException;
import com.service.authentication.service.AuthService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:3000")
@Tag(name = "Authentication Controller", description = "APIs for authentication and user management")
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    @Autowired
    private AuthService authService;

    @Autowired
    private AuthenticationManager authenticationManager;

    private Authentication authenticate;

    @Operation(summary = "Admin access")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @GetMapping("/admin")
    public String getAdmin() {
        logger.info("Admin access granted");
        return "Admin access";
    }

    @Operation(summary = "Manager access")
    @PreAuthorize("hasRole('ROLE_MANAGER')")
    @GetMapping("/manager")
    public String getManager() {
        logger.info("Manager access granted");
        return "Manager Access";
    }

    @Operation(summary = "Register a new user")
    @PostMapping("/register")
    public Response addUser(@RequestBody User user) {
        logger.info("Received request to register user: {}", user);
        try {
            authService.saveUser(user);
            logger.info("User registered successfully: {}", user.getUsername());
            return Response.builder()
                    .success(true)
                    .message("User Registered Successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (UserErrorException e) {
            logger.error("User registration failed: {}", e.getMessage());
            return Response.builder()
                    .success(false)
                    .message(e.getMessage())
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Generate authentication token")
    @PostMapping("/token")
    public Response getToken(@RequestBody User user) {
        logger.info("Received request to generate token for user: {}", user.getUsername());
        try {
            authenticate = authenticationManager
                    .authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
            if (authenticate.isAuthenticated()) {
                String token = authService.generateToken(user.getUsername());
                logger.info("Token generated successfully for user: {}", user.getUsername());
                return Response.builder()
                        .success(true)
                        .message("Token Generated Successfully")
                        .token(token)
                        .code(HttpStatus.SC_OK)
                        .build();
            } else {
                logger.warn("Authentication failed for user: {}", user.getUsername());
                return Response.builder()
                        .success(false)
                        .message("Failure! Token not generated!")
                        .token(null)
                        .code(HttpStatus.SC_BAD_REQUEST)
                        .build();
            }
        } catch (Exception e) {
            logger.error("Error generating token: {}", e.getMessage());
            return Response.builder()
                    .success(false)
                    .message("Invalid username or password")
                    .token(null)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Validate authentication token")
    @GetMapping("/validate")
    public String validateToken(@RequestParam("token") String token) {
        logger.info("Validating token: {}", token);
        authService.validateToken(token);
        logger.info("Token is valid");
        return "Token is valid";
    }
}
