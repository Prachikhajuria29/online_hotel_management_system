package com.service.inventory.exception;

public class StaffNotFoundException extends Exception{
    public StaffNotFoundException(String message) {
           super(message);
    }
}
