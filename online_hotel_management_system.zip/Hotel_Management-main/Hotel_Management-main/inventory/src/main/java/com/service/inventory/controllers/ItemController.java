package com.service.inventory.controllers;

import java.util.List;

import org.apache.hc.core5.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.service.inventory.entities.Item;
import com.service.inventory.entities.Response;
import com.service.inventory.exception.ItemNotFoundException;
import com.service.inventory.services.ItemService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/inventory")
@Tag(name = "Inventory Controller", description = "APIs for managing inventory items")
public class ItemController {

    private static final Logger logger = LoggerFactory.getLogger(ItemController.class);

    @Autowired
    private ItemService itemService;

    @Operation(summary = "Add a new item")
    @PostMapping("/addItem")
    public Response addItem(@RequestBody Item item) {
        logger.info("Received request to add item: {}", item);
        Item result = itemService.addItem(item);
        if (result != null) {
            logger.info("Item added successfully: {}", result);
            return Response.builder()
                    .success(true)
                    .item(result)
                    .message("Item added successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } else {
            logger.error("Failed to add item: {}", item);
            return Response.builder()
                    .success(false)
                    .message("Item not added successfully")
                    .item(item)
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Update an item")
    @PutMapping("/updateItem/{id}")
    public Response updateItem(@RequestBody Item item, @PathVariable int id) {
        logger.info("Received request to update item with ID {}: {}", id, item);
        try {
            Item result = itemService.updateItem(item, id);
            logger.info("Item updated successfully: {}", result);
            return Response.builder()
                    .success(true)
                    .item(result)
                    .message("Item updated successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (ItemNotFoundException e) {
            logger.error("Failed to update item with ID {}: {}", id, e.getMessage());
            return Response.builder()
                    .success(false)
                    .item(item)
                    .message(e.getMessage())
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "Delete an item")
    @DeleteMapping("/deleteItem/{id}")
    public Response deleteItem(@PathVariable int id) {
        logger.info("Received request to delete item with ID {}", id);
        try {
            Item item = itemService.deleteItem(id);
            logger.info("Item deleted successfully with ID {}: {}", id, item);
            return Response.builder()
                    .success(true)
                    .item(item)
                    .message("Item deleted successfully")
                    .code(HttpStatus.SC_OK)
                    .build();
        } catch (ItemNotFoundException e) {
            logger.error("Failed to delete item with ID {}: {}", id, e.getMessage());
            return Response.builder()
                    .success(false)
                    .item(null)
                    .message(e.getMessage())
                    .code(HttpStatus.SC_BAD_REQUEST)
                    .build();
        }
    }

    @Operation(summary = "View all items")
    @GetMapping("/getItems")
    public List<Item> getItems() {
        logger.info("Fetching all items");
        return itemService.getItems();
    }

    @Operation(summary = "Get an item by ID")
    @GetMapping("/getItemById/{id}")
    public Item getItemById(@PathVariable int id) {
        logger.info("Fetching item with ID {}", id);
        return itemService.getItemById(id);
    }
}
